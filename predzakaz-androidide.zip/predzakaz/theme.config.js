/** @type {const} */
const themeColors = {
  primary: { light: "#6F91FF", dark: "#6F91FF" },
  background: { light: "#0B1220", dark: "#0B1220" },
  surface: { light: "#151F33", dark: "#151F33" },
  foreground: { light: "#F4F7FF", dark: "#F4F7FF" },
  muted: { light: "#A4B0C4", dark: "#A4B0C4" },
  border: { light: "#26344D", dark: "#26344D" },
  success: { light: "#51D39B", dark: "#51D39B" },
  warning: { light: "#F5D68F", dark: "#F5D68F" },
  error: { light: "#FF8181", dark: "#FF8181" },
};

module.exports = { themeColors };

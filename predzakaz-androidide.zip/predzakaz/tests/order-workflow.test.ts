import { describe, expect, it } from "vitest";

import {
  buildQrPayload,
  createDocumentNumber,
  getAllSizes,
  getOrderTotal,
  Order,
} from "../lib/order-types";

const order: Order = {
  id: "order-test",
  title: "Поставка белья",
  createdAt: "2026-08-27T10:00:00.000Z",
  updatedAt: "2026-08-27T10:00:00.000Z",
  items: [
    { id: "item-1", category: "Трусы", brand: "Nord", name: "Basic", quantities: { S: 2, M: 3, XL: 1 } },
    { id: "item-2", category: "Носки", brand: "Warm", name: "Cotton", quantities: { "12 лет": 4, M: 1 } },
  ],
};

describe("order calculations", () => {
  it("sums every quantity across all positions", () => {
    expect(getOrderTotal(order)).toBe(11);
  });

  it("collects every size used by the order without duplicates", () => {
    expect(getAllSizes(order.items)).toEqual(["S", "M", "XL", "12 лет"]);
  });
});

describe("document identity", () => {
  it("creates stable, readable and non-equal document numbers for different sequences", () => {
    const date = new Date("2026-08-27T13:14:15.000Z");
    const first = createDocumentNumber(date, 1, "ABC123");
    const second = createDocumentNumber(date, 2, "ABC123");
    expect(first).toBe("PRZ-20260827-131415-0001-ABC123");
    expect(second).toBe("PRZ-20260827-131415-0002-ABC123");
    expect(first).not.toBe(second);
  });
});

describe("QR document payload", () => {
  it("contains the document identity, export moment, total and available company contacts", () => {
    const payload = buildQrPayload({
      order,
      documentNumber: "PRZ-20260827-131415-0001-ABC123",
      exportedAt: "2026-08-27T13:14:15.000Z",
      profile: { companyName: "ООО Комфорт", email: "hello@komfort.ru", phone: "+7 900 111-22-33" },
    });
    expect(payload).toContain("Документ: PRZ-20260827-131415-0001-ABC123");
    expect(payload).toContain("Заказ: Поставка белья");
    expect(payload).toContain("Количество: 11");
    expect(payload).toContain("Компания: ООО Комфорт");
    expect(payload).toContain("Email: hello@komfort.ru");
    expect(payload).toContain("Телефон: +7 900 111-22-33");
  });
});

import { unzipSync } from "fflate";
import { describe, expect, it } from "vitest";

import { buildXlsx } from "../lib/xlsx-core";
import { Order } from "../lib/order-types";

const order: Order = {
  id: "xlsx-order",
  title: "Заказ на май",
  createdAt: "2026-08-27T10:00:00.000Z",
  updatedAt: "2026-08-27T10:00:00.000Z",
  items: [{ id: "item", category: "Пижама", brand: "Home", name: "Soft", quantities: { S: 2, M: 4 } }],
};

describe("XLSX export", () => {
  it("creates a valid zip package with sheet, QR code, logo and export metadata", () => {
    const bytes = buildXlsx({
      order,
      profile: {
        companyName: "ООО Комфорт",
        email: "hello@komfort.ru",
        phone: "+7 900 111-22-33",
        logoMimeType: "image/png",
        logoDataUri: "data:image/png;base64,iVBORw0KGgo=",
      },
      documentNumber: "PRZ-20260827-131415-0001-ABC123",
      exportedAt: "2026-08-27T13:14:15.000Z",
    });
    const files = unzipSync(bytes);
    const sheet = new TextDecoder().decode(files["xl/worksheets/sheet1.xml"]);
    const relationships = new TextDecoder().decode(files["xl/drawings/_rels/drawing1.xml.rels"]);

    expect(files["[Content_Types].xml"]).toBeDefined();
    expect(files["xl/workbook.xml"]).toBeDefined();
    expect(files["xl/media/qr.png"]).toBeDefined();
    expect(files["xl/media/logo.png"]).toBeDefined();
    expect(sheet).toContain("PRZ-20260827-131415-0001-ABC123");
    expect(sheet).toContain("ООО Комфорт");
    expect(sheet).toContain("Дата экспорта");
    expect(sheet).toContain("Время экспорта");
    expect(relationships).toContain("logo.png");
    expect(relationships).toContain("qr.png");
  });
});

import { describe, expect, it } from "vitest";

import {
  clearOrdersFromState,
  deleteOrderFromState,
  parseStoredState,
  saveOrderToState,
} from "../lib/order-persistence";
import { EMPTY_PROFILE, type Order, type PersistedState } from "../lib/order-types";

const baseState = (): PersistedState => ({
  orders: [],
  profile: EMPTY_PROFILE,
  documentSequence: 0,
  usedDocumentNumbers: [],
});

const order = (id: string, updatedAt: string): Order => ({
  id,
  title: `Заказ ${id}`,
  createdAt: updatedAt,
  updatedAt,
  items: [
    {
      id: `item-${id}`,
      category: "Носки",
      brand: "Тест",
      name: "Базовая модель",
      quantities: { S: 2 },
    },
  ],
});

describe("local order persistence helpers", () => {
  it("reads a persisted state and applies safe defaults to invalid storage", () => {
    const parsed = parseStoredState(JSON.stringify({ orders: [order("a", "2026-01-01T00:00:00.000Z")] }));
    expect(parsed.orders).toHaveLength(1);
    expect(parsed.profile).toEqual(EMPTY_PROFILE);
    expect(parseStoredState("{broken-json")).toEqual(baseState());
    expect(parseStoredState(null)).toEqual(baseState());
  });

  it("saves new orders, updates existing orders, and sorts newest first", () => {
    const first = order("a", "2026-01-01T00:00:00.000Z");
    const second = order("b", "2026-01-02T00:00:00.000Z");
    const withFirst = saveOrderToState(baseState(), first, "2026-01-01T00:00:00.000Z");
    const withBoth = saveOrderToState(withFirst, second, "2026-01-03T00:00:00.000Z");
    expect(withBoth.orders.map((item) => item.id)).toEqual(["b", "a"]);

    const updated = saveOrderToState(withBoth, { ...first, title: "Исправленный заказ" }, "2026-01-04T00:00:00.000Z");
    expect(updated.orders).toHaveLength(2);
    expect(updated.orders[0]).toMatchObject({ id: "a", title: "Исправленный заказ" });
  });

  it("clears all orders while preserving company profile and document history", () => {
    const state = {
      ...saveOrderToState(baseState(), order("a", "2026-01-01T00:00:00.000Z")),
      profile: { companyName: "ООО Заказ", email: "mail@example.ru", phone: "+7 900 000-00-00" },
      documentSequence: 7,
      usedDocumentNumbers: ["PRZ-OLD"],
    };
    const cleared = clearOrdersFromState(state);
    expect(cleared.orders).toEqual([]);
    expect(cleared.profile.companyName).toBe("ООО Заказ");
    expect(cleared.documentSequence).toBe(7);
    expect(cleared.usedDocumentNumbers).toEqual(["PRZ-OLD"]);
  });

  it("deletes only the selected order", () => {
    const state = saveOrderToState(saveOrderToState(baseState(), order("a", "2026-01-01T00:00:00.000Z")), order("b", "2026-01-02T00:00:00.000Z"));
    const next = deleteOrderFromState(state, "a");
    expect(next.orders.map((item) => item.id)).toEqual(["b"]);
    expect(deleteOrderFromState(next, "missing")).toEqual(next);
  });
});

# Сборка APK проекта «Заказ» в AndroidIDE

## 1. Распаковка

Скачайте ZIP-архив на смартфон и распакуйте его приложением RAR в отдельную папку, например:

`/storage/emulated/0/AndroidIDEProjects/predzakaz`

В AndroidIDE выберите **Open project** и откройте папку, в которой лежит `package.json`.

## 2. Установка зависимостей

Откройте встроенный Terminal в AndroidIDE. Если доступен `pnpm`, выполните:

```bash
cd /storage/emulated/0/AndroidIDEProjects/predzakaz
pnpm install
```

Если `pnpm` не установлен, используйте npm:

```bash
cd /storage/emulated/0/AndroidIDEProjects/predzakaz
npm install
```

Для первого запуска установка может занять несколько минут.

## 3. Создание Android-проекта

Этот проект является Expo-проектом, поэтому Android-папка создаётся после установки зависимостей. Выполните из корня проекта:

```bash
npx expo prebuild --platform android
```

Команда создаст папку `android/`. Если AndroidIDE покажет запрос на подтверждение перезаписи, для нового проекта можно подтвердить.

## 4. Сборка APK

Выполните:

```bash
cd android
./gradlew assembleDebug
```

Готовый тестовый APK появится по адресу:

`android/app/build/outputs/apk/debug/app-debug.apk`

Его можно открыть через файловый менеджер AndroidIDE или RAR и установить на телефон. Если Android попросит разрешение на установку неизвестных приложений, разрешите его для AndroidIDE или файлового менеджера.

## 5. Если Gradle не запускается

Проверьте в AndroidIDE, что выбран установленный JDK 17 или совместимый JDK, а Android SDK содержит Android SDK Platform и Build-Tools. После установки компонентов повторите:

```bash
cd /storage/emulated/0/AndroidIDEProjects/predzakaz/android
./gradlew assembleDebug --stacktrace
```

Текст ошибки из Terminal лучше сохранить полностью — по нему можно определить недостающий компонент.

## 6. Важные сведения о приложении

Приложение работает офлайн и хранит заказы и настройки компании локально на телефоне. Название и иконка приложения «Заказ» не меняются при замене логотипа компании. Логотип, название, Email и телефон компании настраиваются внутри приложения через шестерёнку и автоматически попадают в следующие Excel-документы.

Перед первой установкой удалять папку `android/` не нужно. При повторной генерации native-проекта используйте:

```bash
npx expo prebuild --platform android --clean
```

Флаг `--clean` перезаписывает сгенерированную Android-папку; пользовательские исходные файлы в папках `app/`, `lib/` и `assets/` он не удаляет.

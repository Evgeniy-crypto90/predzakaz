import { MaterialIcons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useOrderStore } from "@/lib/order-store";
import { AGE_SIZES, createId, getItemTotal, getOrderTotal, Order, OrderItem, PRODUCT_CATEGORIES, STANDARD_SIZES } from "@/lib/order-types";
import { exportOrderToXlsx } from "@/lib/xlsx-export";

const colors = {
  background: "#0B1220",
  surface: "#151F33",
  ink: "#F4F7FF",
  muted: "#A4B0C4",
  blue: "#6F91FF",
  blueDark: "#4C70EA",
  line: "#26344D",
  softBlue: "#1E2E56",
  mint: "#173C39",
  green: "#51D39B",
  danger: "#FF8181",
};

type FormState = {
  category: string;
  brand: string;
  name: string;
  article: string;
  color: string;
  quantities: Record<string, number>;
};

const emptyForm = (): FormState => ({
  category: "Трусы",
  brand: "",
  name: "",
  article: "",
  color: "",
  quantities: Object.fromEntries(STANDARD_SIZES.map((size) => [size, 0])),
});

export default function OrderEditorScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ orderId?: string }>();
  const { hydrated, orders, createOrder, saveOrder, exportOrder, profile } = useOrderStore();
  const [order, setOrder] = useState<Order | null>(null);
  const [title, setTitle] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [customSize, setCustomSize] = useState("");
  const [busy, setBusy] = useState(false);
  const [savedLabel, setSavedLabel] = useState("");
  const initialisedRef = useRef(false);

  useEffect(() => {
    if (!hydrated || initialisedRef.current) return;
    const existing = params.orderId ? orders.find((item) => item.id === params.orderId) : undefined;
    const initial = existing ?? createOrder();
    initialisedRef.current = true;
    setOrder(initial);
    setTitle(initial.title === "Новый заказ" ? "" : initial.title);
  }, [createOrder, hydrated, orders, params.orderId]);

  const total = useMemo(() => (order ? getOrderTotal(order) : 0), [order]);

  const updateCurrentOrder = async (nextOrder: Order) => {
    setOrder(nextOrder);
    await saveOrder(nextOrder);
    setSavedLabel("Сохранено");
    setTimeout(() => setSavedLabel(""), 1800);
  };

  const openNewItem = () => {
    setEditingItemId(null);
    setForm(emptyForm());
    setCustomSize("");
    setModalVisible(true);
  };

  const openEditItem = (item: OrderItem) => {
    setEditingItemId(item.id);
    setForm({
      category: item.category,
      brand: item.brand,
      name: item.name,
      article: item.article ?? "",
      color: item.color ?? "",
      quantities: { ...item.quantities },
    });
    setCustomSize("");
    setModalVisible(true);
  };

  const changeQuantity = (size: string, delta: number) => {
    setForm((current) => ({
      ...current,
      quantities: { ...current.quantities, [size]: Math.max(0, (current.quantities[size] ?? 0) + delta) },
    }));
  };

  const setQuantityFromText = (size: string, value: string) => {
    const safeValue = Math.max(0, Number.parseInt(value.replace(/[^0-9]/g, ""), 10) || 0);
    setForm((current) => ({ ...current, quantities: { ...current.quantities, [size]: safeValue } }));
  };

  const toggleSize = (size: string) => {
    setForm((current) => {
      const next = { ...current.quantities };
      if (size in next) delete next[size];
      else next[size] = 0;
      return { ...current, quantities: next };
    });
  };

  const addCustomSize = () => {
    const size = customSize.trim();
    if (!size) return;
    setForm((current) => ({ ...current, quantities: { ...current.quantities, [size]: current.quantities[size] ?? 0 } }));
    setCustomSize("");
  };

  const saveItem = async () => {
    if (!form.name.trim()) {
      Alert.alert("Укажите товар", "Введите название товара, чтобы добавить позицию.");
      return;
    }
    const totalForItem = Object.values(form.quantities).reduce((sum, value) => sum + value, 0);
    if (totalForItem <= 0) {
      Alert.alert("Добавьте количество", "Укажите хотя бы одну единицу товара в размерах.");
      return;
    }
    if (!order) return;
    const nextItem: OrderItem = {
      id: editingItemId ?? createId("item"),
      category: form.category,
      brand: form.brand.trim(),
      name: form.name.trim(),
      article: form.article.trim() || undefined,
      color: form.color.trim() || undefined,
      quantities: Object.fromEntries(Object.entries(form.quantities).filter(([, value]) => value > 0)),
    };
    const nextItems = editingItemId
      ? order.items.map((item) => (item.id === editingItemId ? nextItem : item))
      : [...order.items, nextItem];
    const nextOrder = { ...order, title: title.trim() || "Новый заказ", items: nextItems, updatedAt: new Date().toISOString() };
    await updateCurrentOrder(nextOrder);
    setModalVisible(false);
  };

  const deleteCurrentItem = () => {
    if (!order || !editingItemId) return;
    const item = order.items.find((candidate) => candidate.id === editingItemId);
    Alert.alert("Удалить позицию?", item ? `«${item.name}» будет удалена из заказа.` : "Позиция будет удалена.", [
      { text: "Отмена", style: "cancel" },
      {
        text: "Удалить",
        style: "destructive",
        onPress: () => {
          const nextOrder = { ...order, items: order.items.filter((candidate) => candidate.id !== editingItemId), updatedAt: new Date().toISOString() };
          void updateCurrentOrder(nextOrder);
          setModalVisible(false);
        },
      },
    ]);
  };

  const handleSave = async () => {
    if (!order) return;
    await updateCurrentOrder({ ...order, title: title.trim() || "Новый заказ", updatedAt: new Date().toISOString() });
  };

  const handleExport = async () => {
    if (!order || order.items.length === 0) {
      Alert.alert("Заказ пустой", "Добавьте хотя бы одну товарную позицию перед экспортом.");
      return;
    }
    setBusy(true);
    try {
      const preparedOrder = { ...order, title: title.trim() || "Новый заказ", updatedAt: new Date().toISOString() };
      await saveOrder(preparedOrder);
      setOrder(preparedOrder);
      const document = await exportOrder(preparedOrder);
      await exportOrderToXlsx({ order: { ...preparedOrder, lastDocumentNumber: document.documentNumber, lastExportedAt: document.exportedAt }, profile, ...document });
    } catch (error) {
      Alert.alert("Не удалось экспортировать", error instanceof Error ? error.message : "Попробуйте ещё раз.");
    } finally {
      setBusy(false);
    }
  };

  if (!hydrated || !order) {
    return <ScreenContainer edges={["top", "bottom", "left", "right"]}><View style={styles.loading}><Text style={styles.loadingText}>Открываем заказ…</Text></View></ScreenContainer>;
  }

  const selectedSizes = Object.keys(form.quantities);

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}>
            <MaterialIcons name="arrow-back" size={23} color={colors.ink} />
          </Pressable>
          <View style={styles.headerCenter}>
            <Text style={styles.eyebrow}>{params.orderId ? "РЕДАКТИРОВАНИЕ" : "НОВЫЙ ЗАКАЗ"}</Text>
            <Text style={styles.headerTitle}>Заказ</Text>
          </View>
          <Pressable onPress={handleSave} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}>
            <MaterialIcons name="check" size={24} color={colors.blue} />
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.titleCard}>
            <Text style={styles.fieldLabel}>Название заказа</Text>
            <TextInput value={title} onChangeText={setTitle} placeholder="Например, поставка на апрель" placeholderTextColor={colors.muted} style={styles.titleInput} returnKeyType="done" />
            <View style={styles.statusLine}>
              <MaterialIcons name="cloud-done" size={16} color={savedLabel ? colors.green : colors.muted} />
              <Text style={[styles.statusText, savedLabel && { color: colors.green }]}>{savedLabel || "Сохраняется на телефоне"}</Text>
            </View>
          </View>

          <View style={styles.sectionHeader}>
            <View>
              <Text style={styles.sectionTitle}>Товарные позиции</Text>
              <Text style={styles.sectionSubtitle}>{order.items.length ? `${order.items.length} позиции в заказе` : "Добавьте первую позицию"}</Text>
            </View>
            <View style={styles.totalPill}><Text style={styles.totalPillNumber}>{total}</Text><Text style={styles.totalPillText}>шт.</Text></View>
          </View>

          {order.items.length === 0 ? (
            <Pressable onPress={openNewItem} style={({ pressed }) => [styles.firstItemCard, pressed && styles.cardPressed]}>
              <View style={styles.addCircle}><MaterialIcons name="add" size={25} color={colors.blue} /></View>
              <Text style={styles.firstItemTitle}>Добавить товар</Text>
              <Text style={styles.firstItemText}>Категория, бренд, название и размеры</Text>
            </Pressable>
          ) : (
            <View style={styles.itemList}>
              {order.items.map((item) => (
                <Pressable key={item.id} onPress={() => openEditItem(item)} style={({ pressed }) => [styles.itemCard, pressed && styles.cardPressed]}>
                  <View style={styles.itemTop}>
                    <View style={styles.categoryBadge}><Text style={styles.categoryBadgeText}>{item.category}</Text></View>
                    <MaterialIcons name="chevron-right" size={22} color={colors.muted} />
                  </View>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemBrand}>{item.brand || "Без бренда"}{item.color ? ` · ${item.color}` : ""}</Text>
                  <View style={styles.sizeLine}>
                    {Object.entries(item.quantities).map(([size, quantity]) => <View key={size} style={styles.sizeChip}><Text style={styles.sizeChipLabel}>{size}</Text><Text style={styles.sizeChipValue}>{quantity}</Text></View>)}
                    <View style={styles.itemTotal}><Text style={styles.itemTotalNumber}>{getItemTotal(item)}</Text><Text style={styles.itemTotalLabel}>шт.</Text></View>
                  </View>
                </Pressable>
              ))}
              <Pressable onPress={openNewItem} style={({ pressed }) => [styles.addMore, pressed && styles.pressed]}>
                <MaterialIcons name="add" size={20} color={colors.blue} /><Text style={styles.addMoreText}>Добавить ещё товар</Text>
              </Pressable>
            </View>
          )}
          <View style={styles.helperCard}><MaterialIcons name="lightbulb-outline" size={19} color="#C77B19" /><Text style={styles.helperText}>Размеры можно добавлять вручную — подойдут S, XL, «12 лет» или любой другой формат.</Text></View>
        </ScrollView>

        <View style={styles.bottomBar}>
          <View><Text style={styles.bottomLabel}>Всего в заказе</Text><Text style={styles.bottomTotal}>{total} <Text style={styles.bottomUnits}>шт.</Text></Text></View>
          <Pressable disabled={busy} onPress={handleExport} style={({ pressed }) => [styles.exportButton, pressed && styles.exportPressed, busy && styles.disabled]}>
            <MaterialIcons name="file-download" size={21} color="#FFFFFF" /><Text style={styles.exportText}>{busy ? "Готовим…" : "Экспорт в Excel"}</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>

      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalGrabber} />
            <View style={styles.modalHeader}><View><Text style={styles.modalEyebrow}>{editingItemId ? "ПОЗИЦИЯ" : "НОВАЯ ПОЗИЦИЯ"}</Text><Text style={styles.modalTitle}>{editingItemId ? "Изменить товар" : "Добавить товар"}</Text></View><Pressable onPress={() => setModalVisible(false)} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}><MaterialIcons name="close" size={22} color={colors.ink} /></Pressable></View>
            <ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <Text style={styles.fieldLabel}>Категория</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryList}>
                {PRODUCT_CATEGORIES.map((category) => <Pressable key={category} onPress={() => setForm((current) => ({ ...current, category }))} style={[styles.categoryChip, form.category === category && styles.categoryChipSelected]}><Text style={[styles.categoryChipText, form.category === category && styles.categoryChipTextSelected]}>{category}</Text></Pressable>)}
              </ScrollView>
              <Text style={styles.fieldLabel}>Название товара *</Text>
              <TextInput value={form.name} onChangeText={(name) => setForm((current) => ({ ...current, name }))} placeholder="Например, боксеры Basic" placeholderTextColor={colors.muted} style={styles.input} returnKeyType="next" />
              <View style={styles.twoFields}><View style={styles.halfField}><Text style={styles.fieldLabel}>Бренд</Text><TextInput value={form.brand} onChangeText={(brand) => setForm((current) => ({ ...current, brand }))} placeholder="Бренд" placeholderTextColor={colors.muted} style={styles.input} returnKeyType="next" /></View><View style={styles.halfField}><Text style={styles.fieldLabel}>Цвет</Text><TextInput value={form.color} onChangeText={(color) => setForm((current) => ({ ...current, color }))} placeholder="Чёрный" placeholderTextColor={colors.muted} style={styles.input} returnKeyType="next" /></View></View>
              <Text style={styles.fieldLabel}>Артикул <Text style={styles.optional}>(необязательно)</Text></Text>
              <TextInput value={form.article} onChangeText={(article) => setForm((current) => ({ ...current, article }))} placeholder="Артикул поставщика" placeholderTextColor={colors.muted} style={styles.input} returnKeyType="done" />

              <View style={styles.sizeHeader}><View><Text style={styles.fieldLabel}>Количество по размерам</Text><Text style={styles.sizeHint}>Нажмите на размер, чтобы добавить или убрать его</Text></View><Text style={styles.formTotal}>{Object.values(form.quantities).reduce((sum, value) => sum + value, 0)} шт.</Text></View>
              <View style={styles.quickSizeRow}>{[...STANDARD_SIZES, ...AGE_SIZES].map((size) => <Pressable key={size} onPress={() => toggleSize(size)} style={[styles.quickSize, size in form.quantities && styles.quickSizeSelected]}><Text style={[styles.quickSizeText, size in form.quantities && styles.quickSizeTextSelected]}>{size}</Text></Pressable>)}</View>
              <View style={styles.sizeRows}>{selectedSizes.map((size) => <View key={size} style={styles.sizeRow}><View style={styles.sizeName}><MaterialIcons name="straighten" size={18} color={colors.blue} /><Text style={styles.sizeNameText}>{size}</Text></View><View style={styles.counter}><Pressable onPress={() => changeQuantity(size, -1)} style={({ pressed }) => [styles.counterButton, pressed && styles.pressed]}><Text style={styles.counterSymbol}>−</Text></Pressable><TextInput value={String(form.quantities[size] ?? 0)} onChangeText={(value) => setQuantityFromText(size, value)} keyboardType="number-pad" style={styles.counterInput} selectTextOnFocus /><Pressable onPress={() => changeQuantity(size, 1)} style={({ pressed }) => [styles.counterButton, styles.counterPlus, pressed && styles.pressed]}><Text style={styles.plusSymbol}>+</Text></Pressable></View></View>)}</View>
              <View style={styles.customSizeRow}><TextInput value={customSize} onChangeText={setCustomSize} placeholder="Другой размер, например 14 лет" placeholderTextColor={colors.muted} style={[styles.input, styles.customSizeInput]} onSubmitEditing={addCustomSize} returnKeyType="done" /><Pressable onPress={addCustomSize} style={({ pressed }) => [styles.customAdd, pressed && styles.pressed]}><MaterialIcons name="add" size={22} color={colors.blue} /></Pressable></View>
            </ScrollView>
            <View style={styles.modalBottom}>{editingItemId ? <Pressable onPress={deleteCurrentItem} style={({ pressed }) => [styles.deleteAction, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={21} color={colors.danger} /><Text style={styles.deleteText}>Удалить</Text></Pressable> : <View />}
              <Pressable onPress={saveItem} style={({ pressed }) => [styles.modalSave, pressed && styles.exportPressed]}><Text style={styles.modalSaveText}>{editingItemId ? "Сохранить изменения" : "Добавить в заказ"}</Text></Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  loading: { flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" },
  loadingText: { color: colors.muted, fontSize: 15 },
  header: { height: 69, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: colors.line, backgroundColor: colors.background },
  headerButton: { width: 44, height: 44, borderRadius: 15, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  headerCenter: { alignItems: "center" },
  eyebrow: { color: colors.blue, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 3 },
  headerTitle: { color: colors.ink, fontSize: 19, fontWeight: "800" },
  pressed: { opacity: 0.65 },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 132, gap: 20 },
  titleCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: 20, padding: 16 },
  fieldLabel: { color: colors.ink, fontSize: 13, fontWeight: "800", marginBottom: 8 },
  titleInput: { color: colors.ink, fontSize: 18, fontWeight: "700", paddingVertical: 4 },
  statusLine: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 9 },
  statusText: { color: colors.muted, fontSize: 12 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { color: colors.ink, fontSize: 19, fontWeight: "800" },
  sectionSubtitle: { color: colors.muted, fontSize: 13, marginTop: 4 },
  totalPill: { backgroundColor: colors.softBlue, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 8, flexDirection: "row", alignItems: "baseline", gap: 4 },
  totalPillNumber: { color: colors.blue, fontSize: 18, fontWeight: "800" },
  totalPillText: { color: colors.blue, fontSize: 11, fontWeight: "700" },
  firstItemCard: { backgroundColor: colors.surface, minHeight: 158, borderRadius: 22, borderWidth: 1.5, borderColor: "#C9D6FB", borderStyle: "dashed", alignItems: "center", justifyContent: "center", padding: 20 },
  cardPressed: { opacity: 0.7 },
  addCircle: { width: 52, height: 52, borderRadius: 18, backgroundColor: colors.softBlue, alignItems: "center", justifyContent: "center", marginBottom: 11 },
  firstItemTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  firstItemText: { color: colors.muted, fontSize: 13, marginTop: 5, textAlign: "center" },
  itemList: { gap: 11 },
  itemCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: 20, padding: 15 },
  itemTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  categoryBadge: { backgroundColor: colors.mint, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 5 },
  categoryBadgeText: { color: colors.green, fontSize: 11, fontWeight: "800" },
  itemName: { color: colors.ink, fontSize: 17, fontWeight: "800", marginTop: 11 },
  itemBrand: { color: colors.muted, fontSize: 13, marginTop: 4 },
  sizeLine: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 7, marginTop: 15 },
  sizeChip: { minWidth: 52, paddingHorizontal: 8, paddingVertical: 6, backgroundColor: colors.softBlue, borderRadius: 9, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5 },
  sizeChipLabel: { color: colors.blue, fontSize: 11, fontWeight: "700" },
  sizeChipValue: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  itemTotal: { marginLeft: "auto", alignItems: "flex-end" },
  itemTotalNumber: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  itemTotalLabel: { color: colors.muted, fontSize: 10 },
  addMore: { minHeight: 51, borderRadius: 16, borderWidth: 1, borderColor: "#C9D6FB", backgroundColor: colors.surface, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  addMoreText: { color: colors.blue, fontSize: 14, fontWeight: "800" },
  helperCard: { padding: 14, borderRadius: 16, backgroundColor: "#3A2D18", flexDirection: "row", gap: 9, alignItems: "flex-start" },
  helperText: { flex: 1, color: "#F5D68F", fontSize: 12, lineHeight: 17 },
  bottomBar: { position: "absolute", left: 0, right: 0, bottom: 0, minHeight: 91, paddingHorizontal: 20, paddingTop: 13, paddingBottom: 15, backgroundColor: "rgba(15,23,36,0.98)", borderTopWidth: 1, borderTopColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 13 },
  bottomLabel: { color: colors.muted, fontSize: 11, marginBottom: 2 },
  bottomTotal: { color: colors.ink, fontSize: 23, fontWeight: "800" },
  bottomUnits: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  exportButton: { minHeight: 54, paddingHorizontal: 16, borderRadius: 17, backgroundColor: colors.blue, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, shadowColor: colors.blueDark, shadowOpacity: 0.2, shadowRadius: 10, shadowOffset: { width: 0, height: 6 }, elevation: 4 },
  exportPressed: { backgroundColor: colors.blueDark, transform: [{ scale: 0.985 }] },
  exportText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  disabled: { opacity: 0.65 },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(23,32,51,0.35)", justifyContent: "flex-end" },
  modalCard: { maxHeight: "93%", backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28, overflow: "hidden" },
  modalGrabber: { alignSelf: "center", marginTop: 10, width: 40, height: 4, borderRadius: 2, backgroundColor: "#CBD2DE" },
  modalHeader: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalEyebrow: { color: colors.blue, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 4 },
  modalTitle: { color: colors.ink, fontSize: 23, fontWeight: "800" },
  closeButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  modalContent: { paddingHorizontal: 20, paddingBottom: 20 },
  categoryList: { gap: 8, paddingBottom: 17 },
  categoryChip: { borderRadius: 12, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 12, minHeight: 39, alignItems: "center", justifyContent: "center" },
  categoryChipSelected: { backgroundColor: colors.blue, borderColor: colors.blue },
  categoryChipText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  categoryChipTextSelected: { color: "#FFFFFF" },
  input: { height: 48, paddingHorizontal: 13, borderRadius: 14, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, color: colors.ink, fontSize: 14, marginBottom: 15 },
  twoFields: { flexDirection: "row", gap: 10 },
  halfField: { flex: 1 },
  optional: { color: colors.muted, fontWeight: "500" },
  sizeHeader: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginTop: 2 },
  sizeHint: { color: colors.muted, fontSize: 11, marginTop: -4, marginBottom: 12, maxWidth: 235 },
  formTotal: { color: colors.blue, fontSize: 15, fontWeight: "800", marginBottom: 12 },
  quickSizeRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 13 },
  quickSize: { minHeight: 36, paddingHorizontal: 11, borderRadius: 11, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" },
  quickSizeSelected: { backgroundColor: colors.softBlue, borderColor: "#AFC3FF" },
  quickSizeText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  quickSizeTextSelected: { color: colors.blue },
  sizeRows: { gap: 9 },
  sizeRow: { minHeight: 59, paddingHorizontal: 12, borderRadius: 15, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sizeName: { flexDirection: "row", alignItems: "center", gap: 8 },
  sizeNameText: { color: colors.ink, fontSize: 15, fontWeight: "800" },
  counter: { height: 40, borderRadius: 12, backgroundColor: colors.background, flexDirection: "row", alignItems: "center", overflow: "hidden", borderWidth: 1, borderColor: colors.line },
  counterButton: { width: 39, height: 40, alignItems: "center", justifyContent: "center" },
  counterPlus: { backgroundColor: colors.blue },
  counterSymbol: { color: colors.ink, fontSize: 22, lineHeight: 24 },
  plusSymbol: { color: "#FFFFFF", fontSize: 21, lineHeight: 24 },
  counterInput: { width: 42, height: 40, textAlign: "center", color: colors.ink, fontSize: 16, fontWeight: "800", paddingVertical: 0 },
  customSizeRow: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 11 },
  customSizeInput: { flex: 1, marginBottom: 0 },
  customAdd: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: colors.softBlue },
  modalBottom: { minHeight: 78, paddingHorizontal: 20, paddingVertical: 13, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  deleteAction: { minHeight: 49, paddingHorizontal: 8, flexDirection: "row", alignItems: "center", gap: 4 },
  deleteText: { color: colors.danger, fontSize: 13, fontWeight: "800" },
  modalSave: { minHeight: 51, paddingHorizontal: 16, borderRadius: 16, backgroundColor: colors.blue, alignItems: "center", justifyContent: "center" },
  modalSaveText: { color: "#FFFFFF", fontSize: 13, fontWeight: "800" },
});

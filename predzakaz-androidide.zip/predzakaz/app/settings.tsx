import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useOrderStore } from "@/lib/order-store";
import { CompanyProfile } from "@/lib/order-types";

const colors = {
  background: "#0B1220",
  surface: "#151F33",
  ink: "#F4F7FF",
  muted: "#A4B0C4",
  blue: "#6F91FF",
  blueDark: "#4C70EA",
  line: "#26344D",
  softBlue: "#1E2E56",
  mint: "#173C39",
  green: "#51D39B",
  danger: "#FF8181",
};

export default function SettingsScreen() {
  const router = useRouter();
  const { profile, saveProfile } = useOrderStore();
  const [companyName, setCompanyName] = useState(profile.companyName);
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(profile.phone);
  const [logoDataUri, setLogoDataUri] = useState(profile.logoDataUri);
  const [logoMimeType, setLogoMimeType] = useState(profile.logoMimeType);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setCompanyName(profile.companyName);
    setEmail(profile.email);
    setPhone(profile.phone);
    setLogoDataUri(profile.logoDataUri);
    setLogoMimeType(profile.logoMimeType);
  }, [profile.companyName, profile.email, profile.logoDataUri, profile.logoMimeType, profile.phone]);

  const currentProfile = (): CompanyProfile => ({ companyName: companyName.trim(), email: email.trim(), phone: phone.trim(), logoDataUri, logoMimeType });

  const save = async () => {
    await saveProfile(currentProfile());
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  const chooseLogo = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.9,
        base64: true,
      });
      if (result.canceled) return;
      const asset = result.assets[0];
      let base64 = asset.base64;
      if (!base64 && Platform.OS !== "web") {
        base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
      }
      if (!base64) throw new Error("Не удалось прочитать изображение. Попробуйте выбрать другую картинку.");
      const mimeType = asset.mimeType || "image/jpeg";
      setLogoDataUri(`data:${mimeType};base64,${base64}`);
      setLogoMimeType(mimeType);
      await saveProfile({ ...currentProfile(), logoDataUri: `data:${mimeType};base64,${base64}`, logoMimeType: mimeType });
      setSaved(true);
      setTimeout(() => setSaved(false), 1800);
    } catch (error) {
      Alert.alert("Не удалось загрузить логотип", error instanceof Error ? error.message : "Попробуйте ещё раз.");
    } finally {
      setBusy(false);
    }
  };

  const removeLogo = () => {
    const remove = async () => {
      setLogoDataUri(undefined);
      setLogoMimeType(undefined);
      await saveProfile({ ...currentProfile(), logoDataUri: undefined, logoMimeType: undefined });
    };
    if (Platform.OS === "web") {
      if (window.confirm("Удалить логотип компании?")) void remove();
      return;
    }
    Alert.alert("Удалить логотип?", "Он исчезнет из следующих экспортных документов.", [
      { text: "Отмена", style: "cancel" },
      { text: "Удалить", style: "destructive", onPress: () => void remove() },
    ]);
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}><MaterialIcons name="arrow-back" size={23} color={colors.ink} /></Pressable>
          <View style={styles.headerCenter}><Text style={styles.eyebrow}>ПРОФИЛЬ МАГАЗИНА</Text><Text style={styles.title}>Настройки</Text></View>
          <Pressable onPress={save} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}><MaterialIcons name={saved ? "check-circle" : "check"} size={24} color={saved ? colors.green : colors.blue} /></Pressable>
        </View>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.intro}><View style={styles.introIcon}><MaterialIcons name="tune" size={22} color={colors.blue} /></View><View style={styles.introCopy}><Text style={styles.introTitle}>Реквизиты для экспорта</Text><Text style={styles.introText}>Заполните только то, что нужно. Данные появятся в шапке Excel-документа.</Text></View></View>

          <View style={styles.card}>
            <View style={styles.cardTitleRow}><View style={styles.cardIcon}><MaterialIcons name="storefront" size={20} color={colors.blue} /></View><View><Text style={styles.cardTitle}>Данные компании</Text><Text style={styles.cardSubtitle}>Необязательные поля</Text></View></View>
            <Text style={styles.label}>Название компании</Text>
            <TextInput value={companyName} onChangeText={setCompanyName} placeholder="Например, ООО «Комфорт»" placeholderTextColor={colors.muted} style={styles.input} returnKeyType="next" />
            <Text style={styles.label}>Email</Text>
            <TextInput value={email} onChangeText={setEmail} placeholder="name@company.ru" placeholderTextColor={colors.muted} style={styles.input} keyboardType="email-address" autoCapitalize="none" returnKeyType="next" />
            <Text style={styles.label}>Номер телефона</Text>
            <TextInput value={phone} onChangeText={setPhone} placeholder="+7 900 000-00-00" placeholderTextColor={colors.muted} style={[styles.input, { marginBottom: 0 }]} keyboardType="phone-pad" returnKeyType="done" />
          </View>

          <View style={styles.card}>
            <View style={styles.cardTitleRow}><View style={[styles.cardIcon, { backgroundColor: colors.mint }]}><MaterialIcons name="image" size={20} color={colors.green} /></View><View><Text style={styles.cardTitle}>Логотип компании</Text><Text style={styles.cardSubtitle}>Покажем его в Excel и в шапке документа</Text></View></View>
            {logoDataUri ? <View style={styles.logoPreviewWrap}><Image source={{ uri: logoDataUri }} resizeMode="contain" style={styles.logoPreview} /></View> : <View style={styles.logoEmpty}><MaterialIcons name="add-photo-alternate" size={29} color={colors.blue} /><Text style={styles.logoEmptyTitle}>Логотип ещё не добавлен</Text><Text style={styles.logoEmptyText}>PNG или JPG из галереи телефона</Text></View>}
            <View style={styles.logoActions}><Pressable onPress={chooseLogo} disabled={busy} style={({ pressed }) => [styles.primaryAction, pressed && styles.pressed, busy && styles.disabled]}><MaterialIcons name={busy ? "hourglass-top" : logoDataUri ? "edit" : "upload"} size={19} color="#FFFFFF" /><Text style={styles.primaryActionText}>{busy ? "Загружаем…" : logoDataUri ? "Заменить / изменить" : "Загрузить логотип"}</Text></Pressable>{logoDataUri ? <Pressable onPress={removeLogo} style={({ pressed }) => [styles.removeAction, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={20} color={colors.danger} /><Text style={styles.removeActionText}>Удалить</Text></Pressable> : null}</View>
            <Text style={styles.logoHint}>При выборе изображения откроется стандартное окно Android с кадрированием.</Text>
          </View>

          <View style={styles.tip}><MaterialIcons name="qr-code-2" size={21} color={colors.blue} /><Text style={styles.tipText}>Эти данные также попадут в QR-код экспортного документа, чтобы поставщик мог быстро проверить контакты.</Text></View>
        </ScrollView>
        <View style={styles.bottomBar}><View><Text style={styles.bottomLabel}>Изменения</Text><Text style={styles.bottomState}>{saved ? "Сохранены" : "Сохраняются локально"}</Text></View><Pressable onPress={save} style={({ pressed }) => [styles.saveButton, pressed && styles.savePressed]}><MaterialIcons name="save" size={20} color="#FFFFFF" /><Text style={styles.saveText}>Сохранить</Text></Pressable></View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: { height: 69, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: colors.line },
  headerButton: { width: 44, height: 44, borderRadius: 15, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  headerCenter: { alignItems: "center" },
  eyebrow: { color: colors.blue, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 3 },
  title: { color: colors.ink, fontSize: 19, fontWeight: "800" },
  pressed: { opacity: 0.65 },
  disabled: { opacity: 0.65 },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 125, gap: 15 },
  intro: { borderRadius: 19, backgroundColor: colors.softBlue, padding: 15, flexDirection: "row", alignItems: "flex-start", gap: 11 },
  introIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" },
  introCopy: { flex: 1 },
  introTitle: { color: colors.ink, fontSize: 15, fontWeight: "800", marginBottom: 4 },
  introText: { color: colors.muted, fontSize: 12, lineHeight: 17 },
  card: { backgroundColor: colors.surface, borderRadius: 21, borderWidth: 1, borderColor: colors.line, padding: 16 },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 17 },
  cardIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: colors.softBlue, alignItems: "center", justifyContent: "center" },
  cardTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  cardSubtitle: { color: colors.muted, fontSize: 11, marginTop: 3 },
  label: { color: colors.ink, fontSize: 12, fontWeight: "800", marginBottom: 7 },
  input: { height: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.background, color: colors.ink, paddingHorizontal: 13, fontSize: 14, marginBottom: 14 },
  logoEmpty: { minHeight: 145, borderWidth: 1.5, borderStyle: "dashed", borderColor: "#C9D6FB", borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "#101827" },
  logoEmptyTitle: { color: colors.ink, fontSize: 14, fontWeight: "800", marginTop: 9 },
  logoEmptyText: { color: colors.muted, fontSize: 11, marginTop: 4 },
  logoPreviewWrap: { height: 153, borderRadius: 17, backgroundColor: "#101827", borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center", padding: 12 },
  logoPreview: { width: "100%", height: "100%" },
  logoActions: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 12 },
  primaryAction: { minHeight: 48, paddingHorizontal: 14, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, backgroundColor: colors.blue, flex: 1 },
  primaryActionText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  removeAction: { minHeight: 48, paddingHorizontal: 11, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, backgroundColor: "#FFF2F2" },
  removeActionText: { color: colors.danger, fontSize: 12, fontWeight: "800" },
  logoHint: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 10 },
  tip: { padding: 14, borderRadius: 16, backgroundColor: colors.mint, flexDirection: "row", alignItems: "flex-start", gap: 9 },
  tipText: { flex: 1, color: "#A7E7CC", fontSize: 12, lineHeight: 17 },
  bottomBar: { position: "absolute", bottom: 0, left: 0, right: 0, minHeight: 83, paddingHorizontal: 20, paddingVertical: 13, borderTopWidth: 1, borderTopColor: colors.line, backgroundColor: "rgba(15,23,36,0.98)", flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  bottomLabel: { color: colors.muted, fontSize: 11 },
  bottomState: { color: colors.ink, fontSize: 13, fontWeight: "700", marginTop: 2 },
  saveButton: { minHeight: 51, borderRadius: 16, backgroundColor: colors.blue, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  savePressed: { backgroundColor: colors.blueDark, transform: [{ scale: 0.985 }] },
  saveText: { color: "#FFFFFF", fontSize: 13, fontWeight: "800" },
});

import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { confirmClearOrders, confirmDeleteOrder, useOrderStore } from "@/lib/order-store";
import { getOrderTotal, Order } from "@/lib/order-types";

const colors = {
  background: "#0B1220",
  surface: "#151F33",
  ink: "#F4F7FF",
  muted: "#A4B0C4",
  blue: "#6F91FF",
  line: "#26344D",
  softBlue: "#1E2E56",
};

export default function OrdersScreen() {
  const router = useRouter();
  const { hydrated, orders, deleteOrder, clearOrders } = useOrderStore();
  const [query, setQuery] = useState("");
  const filteredOrders = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return orders;
    return orders.filter((order) => `${order.title} ${order.lastDocumentNumber ?? ""}`.toLowerCase().includes(normalized));
  }, [orders, query]);

  const renderOrder = ({ item }: { item: Order }) => (
    <Pressable
      onPress={() => router.push({ pathname: "/order-editor" as any, params: { orderId: item.id } })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.cardMain}>
        <View style={styles.iconBox}><MaterialIcons name="receipt-long" size={21} color={colors.blue} /></View>
        <View style={styles.cardCopy}>
          <Text style={styles.orderTitle} numberOfLines={1}>{item.title}</Text>
          <Text style={styles.meta}>{new Date(item.updatedAt).toLocaleDateString("ru-RU")} · {item.items.length} позиций</Text>
          {item.lastDocumentNumber ? <Text style={styles.documentNumber}>{item.lastDocumentNumber}</Text> : null}
        </View>
      </View>
      <View style={styles.cardSide}>
        <Text style={styles.total}>{getOrderTotal(item)}</Text>
        <Text style={styles.units}>шт.</Text>
        <Pressable
          accessibilityLabel={`Удалить заказ ${item.title}`}
          hitSlop={12}
          onPress={() => confirmDeleteOrder(item, () => void deleteOrder(item.id))}
          style={({ pressed }) => [styles.deleteButton, pressed && styles.pressed]}
        >
          <MaterialIcons name="delete-outline" size={21} color="#FF8181" />
        </Pressable>
      </View>
    </Pressable>
  );

  if (!hydrated) {
    return <ScreenContainer edges={["top", "bottom", "left", "right"]}><View style={styles.loading}><ActivityIndicator size="large" color={colors.blue} /></View></ScreenContainer>;
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <View style={styles.screen}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>ИСТОРИЯ</Text>
            <Text style={styles.title}>Мои заказы</Text>
            <Text style={styles.subtitle}>{orders.length ? `${orders.length} сохранённых заказов` : "Здесь будут ваши заказы"}</Text>
          </View>
          <View style={styles.headerActions}>
            {orders.length > 0 ? (
              <Pressable
                accessibilityLabel="Очистить историю заказов"
                onPress={() => confirmClearOrders(orders.length, () => void clearOrders())}
                style={({ pressed }) => [styles.clearHistory, pressed && styles.pressed]}
              >
                <MaterialIcons name="delete-sweep" size={18} color="#FF8181" />
                <Text style={styles.clearHistoryText}>Очистить</Text>
              </Pressable>
            ) : null}
            <Pressable onPress={() => router.push("/settings" as any)} style={({ pressed }) => [styles.settings, pressed && styles.pressed]}>
              <MaterialIcons name="settings" size={23} color={colors.ink} />
            </Pressable>
          </View>
        </View>
        {orders.length > 0 ? (
          <View style={styles.searchWrap}>
            <MaterialIcons name="search" size={21} color={colors.muted} />
            <TextInput value={query} onChangeText={setQuery} placeholder="Поиск по названию или номеру" placeholderTextColor={colors.muted} style={styles.searchInput} returnKeyType="search" />
            {query ? <Pressable onPress={() => setQuery("")}><MaterialIcons name="close" size={20} color={colors.muted} /></Pressable> : null}
          </View>
        ) : null}
        <FlatList
          data={filteredOrders}
          keyExtractor={(item) => item.id}
          renderItem={renderOrder}
          contentContainerStyle={filteredOrders.length ? styles.list : styles.emptyList}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyCard}>
              <View style={styles.emptyIcon}><MaterialIcons name={query ? "search-off" : "inventory-2"} size={28} color={colors.blue} /></View>
              <Text style={styles.emptyTitle}>{query ? "Ничего не найдено" : "Пока нет заказов"}</Text>
              <Text style={styles.emptyText}>{query ? "Попробуйте другое название или номер документа." : "Создайте заказ на первой вкладке — он сохранится здесь автоматически."}</Text>
              {!query ? <Pressable onPress={() => router.push("/order-editor" as any)} style={({ pressed }) => [styles.emptyAction, pressed && styles.pressed]}><Text style={styles.emptyActionText}>Создать первый заказ</Text></Pressable> : null}
            </View>
          }
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: 20, paddingTop: 18 },
  header: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 18 },
  eyebrow: { color: colors.blue, fontSize: 11, fontWeight: "800", letterSpacing: 1.3, marginBottom: 6 },
  title: { color: colors.ink, fontSize: 31, lineHeight: 37, fontWeight: "800", letterSpacing: -0.6 },
  subtitle: { color: colors.muted, fontSize: 14, marginTop: 5 },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  clearHistory: { minHeight: 44, paddingHorizontal: 11, borderRadius: 14, backgroundColor: "#3A2028", borderWidth: 1, borderColor: "#663744", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5 },
  clearHistoryText: { color: "#FFB0B0", fontSize: 12, fontWeight: "800" },
  settings: { width: 48, height: 48, borderRadius: 16, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  pressed: { opacity: 0.65 },
  searchWrap: { height: 50, borderRadius: 16, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, marginBottom: 13 },
  searchInput: { flex: 1, color: colors.ink, fontSize: 14, paddingVertical: 0 },
  list: { paddingBottom: 28, gap: 10 },
  emptyList: { flexGrow: 1, justifyContent: "center", paddingBottom: 60 },
  card: { backgroundColor: colors.surface, borderRadius: 19, minHeight: 88, padding: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderColor: colors.line },
  cardMain: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  iconBox: { width: 43, height: 43, borderRadius: 14, backgroundColor: colors.softBlue, alignItems: "center", justifyContent: "center" },
  cardCopy: { flex: 1 },
  orderTitle: { color: colors.ink, fontSize: 15, fontWeight: "700", marginBottom: 4 },
  meta: { color: colors.muted, fontSize: 12 },
  documentNumber: { color: colors.blue, fontSize: 10, marginTop: 4, fontWeight: "700" },
  cardSide: { alignItems: "flex-end", paddingLeft: 10 },
  total: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  units: { color: colors.muted, fontSize: 11, marginTop: -2 },
  deleteButton: { marginTop: 5, padding: 2 },
  emptyCard: { alignItems: "center", backgroundColor: colors.surface, borderRadius: 23, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 23, paddingVertical: 26 },
  emptyIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: colors.softBlue, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  emptyTitle: { color: colors.ink, fontSize: 17, fontWeight: "800", textAlign: "center" },
  emptyText: { color: colors.muted, fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 7 },
  emptyAction: { marginTop: 18, backgroundColor: colors.blue, borderRadius: 14, minHeight: 46, paddingHorizontal: 18, alignItems: "center", justifyContent: "center" },
  emptyActionText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  loading: { flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" },
});

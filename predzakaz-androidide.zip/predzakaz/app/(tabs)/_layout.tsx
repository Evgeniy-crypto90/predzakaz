import { MaterialIcons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 58 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: "#2457E6",
        tabBarInactiveTintColor: "#8A94A6",
        tabBarStyle: {
          height: tabBarHeight,
          paddingTop: 8,
          paddingBottom: bottomPadding,
          backgroundColor: "#FFFFFF",
          borderTopColor: "#E5E9F2",
          borderTopWidth: 1,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "700" },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Новый заказ",
          tabBarIcon: ({ color }) => <MaterialIcons name="add-box" size={25} color={color} />,
        }}
      />
      <Tabs.Screen
        name="orders"
        options={{
          title: "Мои заказы",
          tabBarIcon: ({ color }) => <MaterialIcons name="receipt-long" size={25} color={color} />,
        }}
      />
    </Tabs>
  );
}

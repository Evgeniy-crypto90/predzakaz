import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useOrderStore } from "@/lib/order-store";
import { getOrderTotal } from "@/lib/order-types";

const colors = {
  background: "#0B1220",
  surface: "#151F33",
  ink: "#F4F7FF",
  muted: "#A4B0C4",
  blue: "#6F91FF",
  blueDark: "#4C70EA",
  line: "#26344D",
  mint: "#173C39",
  green: "#51D39B",
};

export default function HomeScreen() {
  const router = useRouter();
  const { hydrated, orders } = useOrderStore();
  const latestOrders = useMemo(() => orders.slice(0, 3), [orders]);
  const totalUnits = useMemo(() => orders.reduce((total, order) => total + getOrderTotal(order), 0), [orders]);

  if (!hydrated) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]}>
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue} />
          <Text style={styles.loadingText}>Загружаем ваши заказы…</Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <View style={styles.screen}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View>
              <Text style={styles.eyebrow}>РАБОЧИЙ СТЕНД</Text>
              <Text style={styles.title}>Заказ</Text>
              <Text style={styles.subtitle}>Соберите заказ и отправьте его поставщику</Text>
            </View>
            <Pressable
              accessibilityLabel="Открыть настройки"
              onPress={() => router.push("/settings" as any)}
              style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
            >
              <MaterialIcons name="settings" size={24} color={colors.ink} />
            </Pressable>
          </View>

          <Pressable
            onPress={() => router.push("/order-editor" as any)}
            style={({ pressed }) => [styles.heroButton, pressed && styles.heroPressed]}
          >
            <View style={styles.heroCopy}>
              <View style={styles.heroIcon}><MaterialIcons name="add" size={28} color="#FFFFFF" /></View>
              <View>
                <Text style={styles.heroTitle}>Новый заказ</Text>
                <Text style={styles.heroSubtitle}>Добавьте товары и размеры</Text>
              </View>
            </View>
            <MaterialIcons name="arrow-forward" size={24} color="#FFFFFF" />
          </Pressable>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: "#1E2E56" }]}>
                <MaterialIcons name="description" size={19} color={colors.blue} />
              </View>
              <Text style={styles.statValue}>{orders.length}</Text>
              <Text style={styles.statLabel}>заказов сохранено</Text>
            </View>
            <View style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: colors.mint }]}>
                <MaterialIcons name="inventory-2" size={19} color={colors.green} />
              </View>
              <Text style={styles.statValue}>{totalUnits}</Text>
              <Text style={styles.statLabel}>изделий в истории</Text>
            </View>
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Последние заказы</Text>
            <Pressable onPress={() => router.push("/orders" as any)} style={({ pressed }) => [pressed && styles.pressed]}>
              <Text style={styles.link}>Все заказы</Text>
            </Pressable>
          </View>

          {latestOrders.length === 0 ? (
            <View style={styles.emptyCard}>
              <View style={styles.emptyIcon}><MaterialIcons name="inbox" size={26} color={colors.blue} /></View>
              <Text style={styles.emptyTitle}>Здесь появятся ваши заказы</Text>
              <Text style={styles.emptyText}>Создайте первый заказ — он сохранится автоматически после добавления товара.</Text>
            </View>
          ) : (
            <View style={styles.orderList}>
              {latestOrders.map((order) => (
                <Pressable
                  key={order.id}
                  onPress={() => router.push({ pathname: "/order-editor" as any, params: { orderId: order.id } })}
                  style={({ pressed }) => [styles.orderCard, pressed && styles.cardPressed]}
                >
                  <View style={styles.orderLeading}>
                    <View style={styles.orderIcon}><MaterialIcons name="receipt-long" size={20} color={colors.blue} /></View>
                    <View style={styles.orderCopy}>
                      <Text style={styles.orderTitle} numberOfLines={1}>{order.title}</Text>
                      <Text style={styles.orderMeta}>{new Date(order.updatedAt).toLocaleDateString("ru-RU")} · {order.items.length} поз.</Text>
                    </View>
                  </View>
                  <View style={styles.orderTotal}>
                    <Text style={styles.orderNumber}>{getOrderTotal(order)}</Text>
                    <Text style={styles.orderUnits}>шт.</Text>
                  </View>
                </Pressable>
              ))}
            </View>
          )}
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 36, gap: 22 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, backgroundColor: colors.background },
  loadingText: { color: colors.muted, fontSize: 15 },
  header: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  eyebrow: { color: colors.blue, fontSize: 11, fontWeight: "800", letterSpacing: 1.3, marginBottom: 6 },
  title: { color: colors.ink, fontSize: 32, lineHeight: 38, fontWeight: "800", letterSpacing: -0.6 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 21, marginTop: 5, maxWidth: 280 },
  iconButton: { width: 48, height: 48, borderRadius: 16, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  pressed: { opacity: 0.65 },
  heroButton: { backgroundColor: colors.blue, minHeight: 92, borderRadius: 24, paddingHorizontal: 18, paddingVertical: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", shadowColor: colors.blueDark, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.18, shadowRadius: 16, elevation: 4 },
  heroPressed: { backgroundColor: colors.blueDark, transform: [{ scale: 0.985 }] },
  heroCopy: { flexDirection: "row", alignItems: "center", gap: 13 },
  heroIcon: { width: 50, height: 50, borderRadius: 17, backgroundColor: "rgba(15,23,36,0.98)", alignItems: "center", justifyContent: "center" },
  heroTitle: { color: "#FFFFFF", fontSize: 19, fontWeight: "800", marginBottom: 4 },
  heroSubtitle: { color: "#DDE6FF", fontSize: 14 },
  statsRow: { flexDirection: "row", gap: 12 },
  statCard: { flex: 1, backgroundColor: colors.surface, borderRadius: 20, padding: 15, borderWidth: 1, borderColor: colors.line, minHeight: 124 },
  statIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center", marginBottom: 11 },
  statValue: { color: colors.ink, fontSize: 23, fontWeight: "800", lineHeight: 28 },
  statLabel: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 2 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 2 },
  sectionTitle: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  link: { color: colors.blue, fontSize: 14, fontWeight: "700" },
  emptyCard: { backgroundColor: colors.surface, borderRadius: 22, padding: 22, alignItems: "center", borderWidth: 1, borderColor: colors.line },
  emptyIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: "#1E2E56", alignItems: "center", justifyContent: "center", marginBottom: 12 },
  emptyTitle: { color: colors.ink, fontSize: 16, fontWeight: "800", textAlign: "center" },
  emptyText: { color: colors.muted, fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 6 },
  orderList: { gap: 10 },
  orderCard: { backgroundColor: colors.surface, borderRadius: 19, padding: 14, minHeight: 72, borderWidth: 1, borderColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardPressed: { opacity: 0.7 },
  orderLeading: { flexDirection: "row", alignItems: "center", flex: 1, gap: 12 },
  orderIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: "#1E2E56", alignItems: "center", justifyContent: "center" },
  orderCopy: { flex: 1 },
  orderTitle: { color: colors.ink, fontSize: 15, fontWeight: "700", marginBottom: 4 },
  orderMeta: { color: colors.muted, fontSize: 12 },
  orderTotal: { alignItems: "flex-end", paddingLeft: 12 },
  orderNumber: { color: colors.ink, fontSize: 18, fontWeight: "800" },
  orderUnits: { color: colors.muted, fontSize: 11, marginTop: -2 },
});

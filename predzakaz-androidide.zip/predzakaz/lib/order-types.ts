export const STANDARD_SIZES = ["S", "M", "L", "XL"] as const;
export const AGE_SIZES = ["12 лет", "13 лет", "14 лет"] as const;

export const PRODUCT_CATEGORIES = [
  "Трусы",
  "Носки",
  "Пижама",
  "Нижнее бельё",
  "Другое",
] as const;

export type ProductCategory = (typeof PRODUCT_CATEGORIES)[number];

export type OrderItem = {
  id: string;
  category: string;
  brand: string;
  name: string;
  article?: string;
  color?: string;
  quantities: Record<string, number>;
};

export type CompanyProfile = {
  companyName: string;
  email: string;
  phone: string;
  logoDataUri?: string;
  logoMimeType?: string;
};

export type Order = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  items: OrderItem[];
  lastDocumentNumber?: string;
  lastExportedAt?: string;
};

export type PersistedState = {
  orders: Order[];
  profile: CompanyProfile;
  documentSequence: number;
  usedDocumentNumbers: string[];
};

export const EMPTY_PROFILE: CompanyProfile = {
  companyName: "",
  email: "",
  phone: "",
};

export const createId = (prefix: string) =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;

export const createEmptyOrder = (): Order => {
  const now = new Date().toISOString();
  return {
    id: createId("order"),
    title: "Новый заказ",
    createdAt: now,
    updatedAt: now,
    items: [],
  };
};

export const getOrderTotal = (order: Pick<Order, "items">) =>
  order.items.reduce(
    (orderTotal, item) =>
      orderTotal +
      Object.values(item.quantities).reduce((itemTotal, quantity) => itemTotal + quantity, 0),
    0,
  );

export const getItemTotal = (item: Pick<OrderItem, "quantities">) =>
  Object.values(item.quantities).reduce((total, quantity) => total + quantity, 0);

export const getAllSizes = (items: OrderItem[]) => {
  const sizes = new Set<string>();
  items.forEach((item) => {
    Object.keys(item.quantities).forEach((size) => sizes.add(size));
  });
  return Array.from(sizes);
};

export const createDocumentNumber = (date: Date, sequence: number, randomPart = "") => {
  const pad = (value: number) => value.toString().padStart(2, "0");
  const datePart = [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
  ].join("");
  const timePart = [pad(date.getHours()), pad(date.getMinutes()), pad(date.getSeconds())].join("");
  const sequencePart = sequence.toString(36).toUpperCase().padStart(4, "0");
  const suffix = randomPart || Math.random().toString(36).slice(2, 8).toUpperCase();
  return `PRZ-${datePart}-${timePart}-${sequencePart}-${suffix}`;
};

export const buildQrPayload = ({
  documentNumber,
  exportedAt,
  profile,
  order,
}: {
  documentNumber: string;
  exportedAt: string;
  profile: CompanyProfile;
  order: Order;
}) => {
  const exported = new Date(exportedAt);
  const date = exported.toLocaleDateString("ru-RU");
  const time = exported.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  const lines = [
    "ЗАКАЗ",
    `Документ: ${documentNumber}`,
    `Заказ: ${order.title}`,
    `Дата: ${date}`,
    `Время: ${time}`,
    `Количество: ${getOrderTotal(order)}`,
  ];
  if (profile.companyName.trim()) lines.push(`Компания: ${profile.companyName.trim()}`);
  if (profile.email.trim()) lines.push(`Email: ${profile.email.trim()}`);
  if (profile.phone.trim()) lines.push(`Телефон: ${profile.phone.trim()}`);
  return lines.join("\n");
};

export const normalisePersistedState = (value: Partial<PersistedState> | null | undefined): PersistedState => ({
  orders: Array.isArray(value?.orders) ? value.orders : [],
  profile: {
    ...EMPTY_PROFILE,
    ...(value?.profile ?? {}),
  },
  documentSequence:
    typeof value?.documentSequence === "number" && Number.isFinite(value.documentSequence)
      ? value.documentSequence
      : 0,
  usedDocumentNumbers: Array.isArray(value?.usedDocumentNumbers) ? value.usedDocumentNumbers : [],
});

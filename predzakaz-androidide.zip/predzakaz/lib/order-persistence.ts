import { normalisePersistedState, type Order, type PersistedState } from "./order-types";

export const sortOrders = (orders: Order[]) =>
  [...orders].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

export const parseStoredState = (raw: string | null): PersistedState => {
  try {
    return normalisePersistedState(raw ? JSON.parse(raw) : null);
  } catch {
    return normalisePersistedState(null);
  }
};

export const saveOrderToState = (state: PersistedState, order: Order, updatedAt = new Date().toISOString()): PersistedState => {
  const nextOrder = { ...order, updatedAt };
  const existingIndex = state.orders.findIndex((item) => item.id === nextOrder.id);
  const nextOrders = [...state.orders];
  if (existingIndex >= 0) nextOrders[existingIndex] = nextOrder;
  else nextOrders.push(nextOrder);
  return { ...state, orders: sortOrders(nextOrders) };
};

export const deleteOrderFromState = (state: PersistedState, orderId: string): PersistedState => ({
  ...state,
  orders: state.orders.filter((order) => order.id !== orderId),
});

export const clearOrdersFromState = (state: PersistedState): PersistedState => ({
  ...state,
  orders: [],
});

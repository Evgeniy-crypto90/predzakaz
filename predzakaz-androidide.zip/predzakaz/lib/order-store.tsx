import AsyncStorage from "@react-native-async-storage/async-storage";
import { usePathname, useRouter } from "expo-router";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Alert, Platform } from "react-native";

import {
  CompanyProfile,
  createDocumentNumber,
  createEmptyOrder,
  EMPTY_PROFILE,
  normalisePersistedState,
  Order,
  OrderItem,
  PersistedState,
} from "@/lib/order-types";
import {
  clearOrdersFromState,
  deleteOrderFromState,
  parseStoredState,
  saveOrderToState,
  sortOrders,
} from "@/lib/order-persistence";

export { clearOrdersFromState, deleteOrderFromState, parseStoredState, saveOrderToState, sortOrders } from "@/lib/order-persistence";

const STORAGE_KEY = "predzakaz.local.v1";

type OrderStoreValue = {
  hydrated: boolean;
  orders: Order[];
  profile: CompanyProfile;
  saveProfile: (profile: CompanyProfile) => Promise<void>;
  createOrder: () => Order;
  saveOrder: (order: Order) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  clearOrders: () => Promise<void>;
  exportOrder: (order: Order) => Promise<{ documentNumber: string; exportedAt: string }>;
};

const OrderStoreContext = createContext<OrderStoreValue | null>(null);

export function OrderStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<PersistedState>({
    orders: [],
    profile: EMPTY_PROFILE,
    documentSequence: 0,
    usedDocumentNumbers: [],
  });
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!mounted) return;
        try {
          setState(parseStoredState(raw));
        } finally {
          setHydrated(true);
        }
      })
      .catch(() => {
        if (mounted) setHydrated(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const persist = useCallback(async (next: PersistedState) => {
    setState(next);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const saveProfile = useCallback(
    async (profile: CompanyProfile) => {
      await persist({ ...state, profile });
    },
    [persist, state],
  );

  const createOrder = useCallback(() => createEmptyOrder(), []);

  const saveOrder = useCallback(
    async (order: Order) => {
      await persist(saveOrderToState(state, order));
    },
    [persist, state],
  );

  const deleteOrder = useCallback(
    async (orderId: string) => {
      await persist(deleteOrderFromState(state, orderId));
    },
    [persist, state],
  );

  const clearOrders = useCallback(async () => {
    await persist(clearOrdersFromState(state));
  }, [persist, state]);

  const exportOrder = useCallback(
    async (order: Order) => {
      const exportedAt = new Date().toISOString();
      let sequence = state.documentSequence + 1;
      let documentNumber = createDocumentNumber(new Date(exportedAt), sequence);
      const used = new Set(state.usedDocumentNumbers);
      while (used.has(documentNumber)) {
        sequence += 1;
        documentNumber = createDocumentNumber(new Date(exportedAt), sequence);
      }
      used.add(documentNumber);
      const exportedOrder: Order = {
        ...order,
        lastDocumentNumber: documentNumber,
        lastExportedAt: exportedAt,
        updatedAt: new Date().toISOString(),
      };
      const existingIndex = state.orders.findIndex((item) => item.id === exportedOrder.id);
      const nextOrders = [...state.orders];
      if (existingIndex >= 0) nextOrders[existingIndex] = exportedOrder;
      else nextOrders.push(exportedOrder);
      await persist({
        ...state,
        orders: sortOrders(nextOrders),
        documentSequence: sequence,
        usedDocumentNumbers: Array.from(used),
      });
      return { documentNumber, exportedAt };
    },
    [persist, state],
  );

  const value = useMemo(
    () => ({
      hydrated,
      orders: sortOrders(state.orders),
      profile: state.profile,
      saveProfile,
      createOrder,
      saveOrder,
      deleteOrder,
      clearOrders,
      exportOrder,
    }),
    [clearOrders, createOrder, deleteOrder, exportOrder, hydrated, saveOrder, saveProfile, state.orders, state.profile],
  );

  return <OrderStoreContext.Provider value={value}>{children}</OrderStoreContext.Provider>;
}

export function useOrderStore() {
  const value = useContext(OrderStoreContext);
  if (!value) throw new Error("useOrderStore must be used inside OrderStoreProvider");
  return value;
}

export function confirmClearOrders(orderCount: number, onConfirm: () => void) {
  if (orderCount < 1) return;
  const message = `Удалить все заказы (${orderCount})? Номерная история документов сохранится, чтобы новые номера не повторялись.`;
  if (Platform.OS === "web") {
    if (window.confirm(message)) onConfirm();
    return;
  }
  Alert.alert("Очистить историю?", message, [
    { text: "Отмена", style: "cancel" },
    { text: "Очистить", style: "destructive", onPress: onConfirm },
  ]);
}

export function confirmDeleteOrder(order: Order, onConfirm: () => void) {
  if (Platform.OS === "web") {
    if (window.confirm(`Удалить заказ «${order.title}»?`)) onConfirm();
    return;
  }
  Alert.alert("Удалить заказ?", `Заказ «${order.title}» будет удалён без возможности восстановления.`, [
    { text: "Отмена", style: "cancel" },
    { text: "Удалить", style: "destructive", onPress: onConfirm },
  ]);
}

export const updateItem = (items: OrderItem[], itemId: string, updater: (item: OrderItem) => OrderItem) =>
  items.map((item) => (item.id === itemId ? updater(item) : item));

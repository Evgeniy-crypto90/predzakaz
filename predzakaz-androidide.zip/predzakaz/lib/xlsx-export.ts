import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";

import { buildXlsx } from "@/lib/xlsx-core";
import { Order, CompanyProfile } from "@/lib/order-types";

const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const base64Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

const bytesToBase64 = (bytes: Uint8Array) => {
  let result = "";
  for (let index = 0; index < bytes.length; index += 3) {
    const a = bytes[index];
    const b = bytes[index + 1] ?? 0;
    const c = bytes[index + 2] ?? 0;
    const triple = (a << 16) | (b << 8) | c;
    result += base64Alphabet[(triple >> 18) & 63];
    result += base64Alphabet[(triple >> 12) & 63];
    result += index + 1 < bytes.length ? base64Alphabet[(triple >> 6) & 63] : "=";
    result += index + 2 < bytes.length ? base64Alphabet[triple & 63] : "=";
  }
  return result;
};

export async function exportOrderToXlsx(input: { order: Order; profile: CompanyProfile; documentNumber: string; exportedAt: string }) {
  const bytes = buildXlsx(input);
  const safeNumber = input.documentNumber.replace(/[^A-Za-z0-9-]/g, "-");
  const fileUri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ""}zakaz-${safeNumber}.xlsx`;
  await FileSystem.writeAsStringAsync(fileUri, bytesToBase64(bytes), { encoding: FileSystem.EncodingType.Base64 });
  const available = await Sharing.isAvailableAsync();
  if (!available) return { fileUri, shared: false };
  await Sharing.shareAsync(fileUri, { mimeType: XLSX_MIME, dialogTitle: "Отправить Excel-заказ" });
  return { fileUri, shared: true };
}

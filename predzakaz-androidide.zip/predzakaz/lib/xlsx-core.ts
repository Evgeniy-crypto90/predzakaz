import QRCode from "qrcode";
import { zipSync, zlibSync } from "fflate";

import { buildQrPayload, CompanyProfile, getAllSizes, Order } from "./order-types";

const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const encoder = new TextEncoder();

const escapeXml = (value: string | number) =>
  String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");

const columnName = (index: number) => {
  let value = index + 1;
  let name = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name;
};

const cellRef = (column: number, row: number) => `${columnName(column)}${row}`;

const makeTextCell = (column: number, row: number, value: string, style = 0) =>
  `<c r="${cellRef(column, row)}" t="inlineStr" s="${style}"><is><t xml:space="preserve">${escapeXml(value)}</t></is></c>`;

const makeNumberCell = (column: number, row: number, value: number, style = 0) =>
  `<c r="${cellRef(column, row)}" s="${style}"><v>${Number.isFinite(value) ? value : 0}</v></c>`;

const makeFormulaCell = (column: number, row: number, formula: string, style = 0) =>
  `<c r="${cellRef(column, row)}" s="${style}"><f>${escapeXml(formula)}</f><v>0</v></c>`;

const base64Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

const bytesToBase64 = (bytes: Uint8Array) => {
  let result = "";
  for (let index = 0; index < bytes.length; index += 3) {
    const a = bytes[index];
    const b = bytes[index + 1] ?? 0;
    const c = bytes[index + 2] ?? 0;
    const triple = (a << 16) | (b << 8) | c;
    result += base64Alphabet[(triple >> 18) & 63];
    result += base64Alphabet[(triple >> 12) & 63];
    result += index + 1 < bytes.length ? base64Alphabet[(triple >> 6) & 63] : "=";
    result += index + 2 < bytes.length ? base64Alphabet[triple & 63] : "=";
  }
  return result;
};

const base64ToBytes = (input: string) => {
  const clean = input.replace(/[^A-Za-z0-9+/=]/g, "");
  const output = new Uint8Array(Math.floor((clean.length * 3) / 4) - (clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0));
  let outputIndex = 0;
  for (let index = 0; index < clean.length; index += 4) {
    const a = base64Alphabet.indexOf(clean[index]);
    const b = base64Alphabet.indexOf(clean[index + 1]);
    const c = clean[index + 2] === "=" ? 0 : base64Alphabet.indexOf(clean[index + 2]);
    const d = clean[index + 3] === "=" ? 0 : base64Alphabet.indexOf(clean[index + 3]);
    const triple = (a << 18) | (b << 12) | (c << 6) | d;
    if (outputIndex < output.length) output[outputIndex++] = (triple >> 16) & 255;
    if (outputIndex < output.length) output[outputIndex++] = (triple >> 8) & 255;
    if (outputIndex < output.length) output[outputIndex++] = triple & 255;
  }
  return output;
};

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});

const crc32 = (bytes: Uint8Array) => {
  let value = 0xffffffff;
  for (const byte of bytes) value = crcTable[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
};

const writeUInt32 = (view: DataView, offset: number, value: number) => view.setUint32(offset, value >>> 0, false);

const createPngFromQr = (payload: string, scale = 5) => {
  const qr = QRCode.create(payload, { errorCorrectionLevel: "M" });
  const moduleCount = qr.modules.size;
  const quietZone = 4;
  const imageSize = (moduleCount + quietZone * 2) * scale;
  const rowBytes = imageSize * 4 + 1;
  const raw = new Uint8Array(rowBytes * imageSize);
  for (let y = 0; y < imageSize; y += 1) {
    const rowOffset = y * rowBytes;
    raw[rowOffset] = 0;
    const moduleY = Math.floor(y / scale) - quietZone;
    for (let x = 0; x < imageSize; x += 1) {
      const moduleX = Math.floor(x / scale) - quietZone;
      const dark = moduleX >= 0 && moduleY >= 0 && moduleX < moduleCount && moduleY < moduleCount && qr.modules.get(moduleX, moduleY);
      const pixelOffset = rowOffset + 1 + x * 4;
      raw[pixelOffset] = dark ? 23 : 255;
      raw[pixelOffset + 1] = dark ? 32 : 255;
      raw[pixelOffset + 2] = dark ? 51 : 255;
      raw[pixelOffset + 3] = 255;
    }
  }
  const compressed = zlibSync(raw, { level: 6 });
  const chunks: Uint8Array[] = [];
  const addChunk = (type: string, data: Uint8Array) => {
    const typeBytes = encoder.encode(type);
    const chunk = new Uint8Array(12 + data.length);
    const view = new DataView(chunk.buffer);
    writeUInt32(view, 0, data.length);
    chunk.set(typeBytes, 4);
    chunk.set(data, 8);
    writeUInt32(view, 8 + data.length, crc32(chunk.slice(4, 8 + data.length)));
    chunks.push(chunk);
  };
  const ihdr = new Uint8Array(13);
  const ihdrView = new DataView(ihdr.buffer);
  writeUInt32(ihdrView, 0, imageSize);
  writeUInt32(ihdrView, 4, imageSize);
  ihdr[8] = 8;
  ihdr[9] = 6;
  addChunk("IHDR", ihdr);
  addChunk("IDAT", compressed);
  addChunk("IEND", new Uint8Array());
  const totalSize = 8 + chunks.reduce((total, chunk) => total + chunk.length, 0);
  const png = new Uint8Array(totalSize);
  png.set(new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]));
  let offset = 8;
  chunks.forEach((chunk) => {
    png.set(chunk, offset);
    offset += chunk.length;
  });
  return png;
};

const worksheetColumns = (sizeCount: number) => {
  const widths = [18, 18, 31, ...Array.from({ length: sizeCount }, () => 11), 12];
  return widths.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join("");
};

const buildStylesXml = () => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="0"/>
  <fonts count="3">
    <font><sz val="11"/><color rgb="FF172033"/><name val="Aptos"/></font>
    <font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Aptos Display"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF2457E6"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF172033"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFEAF0FF"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFE5E9F2"/></left><right style="thin"><color rgb="FFE5E9F2"/></right><top style="thin"><color rgb="FFE5E9F2"/></top><bottom style="thin"><color rgb="FFE5E9F2"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="9">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="2" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

export const buildWorksheetXml = ({ order, profile, documentNumber, exportedAt }: ExportInput) => {
  const sizes = getAllSizes(order.items);
  const lastColumn = 3 + sizes.length;
  const itemStartRow = 10;
  const totalRow = itemStartRow + order.items.length;
  const date = new Date(exportedAt);
  const dateText = date.toLocaleDateString("ru-RU");
  const timeText = date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const cells: string[] = [];
  cells.push(makeTextCell(0, 1, "ЗАКАЗ", 1));
  cells.push(makeTextCell(0, 2, "Заказ", 6), makeTextCell(1, 2, order.title, 4));
  cells.push(makeTextCell(0, 3, "Документ №", 6), makeTextCell(1, 3, documentNumber, 4));
  cells.push(makeTextCell(0, 4, "Дата экспорта", 6), makeTextCell(1, 4, dateText, 4));
  cells.push(makeTextCell(0, 5, "Время экспорта", 6), makeTextCell(1, 5, timeText, 4));
  if (profile.companyName.trim()) cells.push(makeTextCell(0, 6, "Компания", 6), makeTextCell(1, 6, profile.companyName.trim(), 4));
  if (profile.email.trim()) cells.push(makeTextCell(0, 7, "Email", 6), makeTextCell(1, 7, profile.email.trim(), 4));
  if (profile.phone.trim()) cells.push(makeTextCell(0, 8, "Телефон", 6), makeTextCell(1, 8, profile.phone.trim(), 4));

  const headerRow = ["Категория", "Бренд", "Название товара", ...sizes, "Итого"];
  headerRow.forEach((value, index) => cells.push(makeTextCell(index, 9, value, 2)));
  order.items.forEach((item, itemIndex) => {
    const row = itemStartRow + itemIndex;
    cells.push(makeTextCell(0, row, item.category, 3));
    cells.push(makeTextCell(1, row, item.brand, 3));
    const description = [item.name, item.article, item.color].filter(Boolean).join(" · ");
    cells.push(makeTextCell(2, row, description, 3));
    sizes.forEach((size, sizeIndex) => cells.push(makeNumberCell(3 + sizeIndex, row, item.quantities[size] ?? 0, 8)));
    cells.push(makeFormulaCell(lastColumn, row, `SUM(${cellRef(3, row)}:${cellRef(2 + sizes.length, row)})`, 5));
  });
  cells.push(makeTextCell(0, totalRow, "ИТОГО", 7));
  for (let index = 1; index < lastColumn; index += 1) {
    if (index < 3) cells.push(makeTextCell(index, totalRow, "", 7));
    else cells.push(makeFormulaCell(index, totalRow, `SUM(${cellRef(index, itemStartRow)}:${cellRef(index, totalRow - 1)})`, 7));
  }
  cells.push(makeFormulaCell(lastColumn, totalRow, `SUM(${cellRef(lastColumn, itemStartRow)}:${cellRef(lastColumn, totalRow - 1)})`, 7));

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <dimension ref="A1:${cellRef(lastColumn, totalRow)}"/>
  <sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews>
  <sheetFormatPr defaultRowHeight="20"/>
  <cols>${worksheetColumns(sizes.length)}</cols>
  <sheetData><row r="1" ht="30" customHeight="1">${cells.filter((cell) => cell.includes(`r="A1"`)).join("")}</row><row r="2">${cells.filter((cell) => cell.includes(`r="A2"`) || cell.includes(`r="B2"`)).join("")}</row><row r="3">${cells.filter((cell) => cell.includes(`r="A3"`) || cell.includes(`r="B3"`)).join("")}</row><row r="4">${cells.filter((cell) => cell.includes(`r="A4"`) || cell.includes(`r="B4"`)).join("")}</row><row r="5">${cells.filter((cell) => cell.includes(`r="A5"`) || cell.includes(`r="B5"`)).join("")}</row><row r="6">${cells.filter((cell) => cell.includes(`r="A6"`) || cell.includes(`r="B6"`)).join("")}</row><row r="7">${cells.filter((cell) => cell.includes(`r="A7"`) || cell.includes(`r="B7"`)).join("")}</row><row r="8">${cells.filter((cell) => cell.includes(`r="A8"`) || cell.includes(`r="B8"`)).join("")}</row><row r="9" ht="32" customHeight="1">${cells.filter((cell) => cell.includes(`r="${cellRef(0, 9)}"`) || cell.includes(`r="${cellRef(lastColumn, 9)}"`) || (cell.match(/r="[A-Z]+9"/) && !cell.includes("r=\"A9\""))).join("")}</row>${Array.from({ length: order.items.length }, (_, index) => { const row = itemStartRow + index; return `<row r="${row}">${cells.filter((cell) => cell.match(new RegExp(`r=\"[A-Z]+${row}\"`))).join("")}</row>`; }).join("")}<row r="${totalRow}" ht="24" customHeight="1">${cells.filter((cell) => cell.match(new RegExp(`r=\"[A-Z]+${totalRow}\"`))).join("")}</row></sheetData>
  <mergeCells count="1"><mergeCell ref="A1:C1"/></mergeCells>
  <pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>
  <pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>
  <drawing r:id="rId1"/>
</worksheet>`;
};

type ExportInput = {
  order: Order;
  profile: CompanyProfile;
  documentNumber: string;
  exportedAt: string;
};

const buildDrawingXml = ({ logo, qr, sheetWidth }: { logo: boolean; qr: boolean; sheetWidth: number }) => {
  const anchors: string[] = [];
  if (logo) {
    anchors.push(`<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>120000</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>120000</xdr:rowOff></xdr:from><xdr:ext cx="1320000" cy="680000"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Company logo"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="1320000" cy="680000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>`);
  }
  if (qr) {
    const qrRel = logo ? "rId2" : "rId1";
    anchors.push(`<xdr:oneCellAnchor><xdr:from><xdr:col>${Math.max(sheetWidth - 1, 4)}</xdr:col><xdr:colOff>120000</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>120000</xdr:rowOff></xdr:from><xdr:ext cx="1050000" cy="1050000"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="3" name="Document QR code"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="${qrRel}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="1050000" cy="1050000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>`);
  }
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">${anchors.join("")}</xdr:wsDr>`;
};

export const buildXlsx = ({ order, profile, documentNumber, exportedAt }: ExportInput) => {
  const sizes = getAllSizes(order.items);
  const sheetXml = buildWorksheetXml({ order, profile, documentNumber, exportedAt });
  const qrPayload = buildQrPayload({ documentNumber, exportedAt, profile, order });
  const qrPng = createPngFromQr(qrPayload);
  const logoData = profile.logoDataUri ? base64ToBytes(profile.logoDataUri.split(",")[1] ?? "") : null;
  const logoMime = profile.logoMimeType || profile.logoDataUri?.match(/^data:([^;]+);/)?.[1] || "image/png";
  const logoExtension = logoMime.includes("jpeg") || logoMime.includes("jpg") ? "jpg" : "png";
  const hasLogo = Boolean(logoData?.length);
  const drawingXml = buildDrawingXml({ logo: hasLogo, qr: true, sheetWidth: 4 + sizes.length });
  const drawingRels = [
    hasLogo ? `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/logo.${logoExtension}"/>` : "",
    `<Relationship Id="${hasLogo ? "rId2" : "rId1"}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/qr.png"/>`,
  ].join("");
  const sheetRels = `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>`;
  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets><sheet name="Предзаказ" sheetId="1" r:id="rId1"/></sheets></workbook>`;
  const workbookRels = `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const rootRels = `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`;
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`;
  const now = escapeXml(exportedAt);
  const files: Record<string, Uint8Array> = {
    "[Content_Types].xml": encoder.encode(contentTypes),
    "_rels/.rels": encoder.encode(rootRels),
    "docProps/core.xml": encoder.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/"><dc:title>Предзаказ ${escapeXml(documentNumber)}</dc:title><dc:creator>Предзаказ</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">${now}</dcterms:created></cp:coreProperties>`),
    "docProps/app.xml": encoder.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Предзаказ</Application><AppVersion>1.0</AppVersion></Properties>`),
    "xl/workbook.xml": encoder.encode(workbookXml),
    "xl/_rels/workbook.xml.rels": encoder.encode(workbookRels),
    "xl/styles.xml": encoder.encode(buildStylesXml()),
    "xl/worksheets/sheet1.xml": encoder.encode(sheetXml),
    "xl/worksheets/_rels/sheet1.xml.rels": encoder.encode(sheetRels),
    "xl/drawings/drawing1.xml": encoder.encode(drawingXml),
    "xl/drawings/_rels/drawing1.xml.rels": encoder.encode(`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${drawingRels}</Relationships>`),
    "xl/media/qr.png": qrPng,
  };
  if (hasLogo && logoData) files[`xl/media/logo.${logoExtension}`] = logoData;
  return zipSync(files, { level: 6 });
};

export const __testing = { base64ToBytes, bytesToBase64, createPngFromQr, buildXlsx, buildWorksheetXml };

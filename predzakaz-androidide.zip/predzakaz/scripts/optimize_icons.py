from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSET_NAMES = [
    "icon.png",
    "splash-icon.png",
    "favicon.png",
    "android-icon-foreground.png",
]

for name in ASSET_NAMES:
    path = ROOT / "assets" / "images" / name
    image = Image.open(path).convert("RGBA")
    image.thumbnail((512, 512), Image.Resampling.LANCZOS)
    image.save(path, format="PNG", optimize=True, compress_level=9)
    print(f"{name}: {path.stat().st_size} bytes")
